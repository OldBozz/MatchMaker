﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MatchMakerLib.MatchMakerModel.Bet
{
    public class BetMatch : Bet
    {
        public Match? Match { get; set; }

    }
}
